from flask import Flask, render_template, request, redirect, session, url_for
import mysql.connector
from numpy import convolve
app = Flask(__name__)

app = Flask(__name__)
app.secret_key = "supersecretkey123" 

def get_db_connection(): #db connection
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Balajanani2406",
        database="healthcare"
    )


@app.route("/") #default home page
def home():
    return render_template("user/login.html")

@app.route('/admin',methods=["GET","POST"]) # Admin login with authentication
def admin_login():
    if request.method=="POST":
        username =request.form["username"]
        password=request.form["password"]
        
        if username == "Janani" and password == "2406":
            session["Janani"]= True
            return redirect(url_for("admindashboard"))
        else:
            return "Invalid Credentials"
        
    return render_template("admin/adminlogin.html")
    
@app.route('/admin/show_doctors') #in admin this is show doctor page
def show_doctor():
    conn=get_db_connection()
    cur=conn.cursor()
    cur.execute("SELECT * FROM doctor")    
    data=cur.fetchall()
    cur.close()
    conn.close()
    return render_template("admin/showdoctor.html",doctors=data)

@app.route('/admin/show_disease') #in admin side this is show disease page
def show_disease():
    conn=get_db_connection()
    cur=conn.cursor()
    cur.execute("SELECT * from disease")
    data=cur.fetchall()
    cur.close()
    conn.close()
    return render_template("admin/showdisease.html" ,disease=data)

@app.route("/deletedoc/<string:Id>")
def delete_doctor(Id):
    conn=get_db_connection()
    cur=conn.cursor()
    cur.execute("DELETE FROM doctor where id=%s",(Id,))
    conn.commit()
    cur.close()
    conn.close()
    return redirect("/admin/show_doctors")

@app.route("/disease", methods=["GET", "POST"])
def disease():
    conn = get_db_connection()
    cur = conn.cursor()

    # Get all dropdown options
    cur.execute("SELECT DISTINCT speciality FROM doctor")
    specialities = [row[0] for row in cur.fetchall()]

    # Selected speciality
    selected = request.form.get("speciality") if request.method == "POST" else ""

    # Fetch doctors based on selection
    if selected:
        cur.execute("SELECT id,name,speciality,experience FROM doctor WHERE speciality=%s", (selected,))
    else:
        cur.execute("SELECT id,name,speciality,experience FROM doctor")

    doctors = cur.fetchall()

    cur.close()
    conn.close()

    return render_template("user/disease.html",specialities=specialities,doctors=doctors,selected=selected)





@app.route("/deletedis/<string:Id>")
def delete_disease(Id):
    conn=get_db_connection()
    cur=conn.cursor()
    cur.execute("DELETE FROM disease where id=%s",(Id,))
    conn.commit()
    cur.close()
    conn.close()
    return redirect("/admin/show_disease")


  

@app.route('/admindashboard') #admin dashboard
def admindashboard():
    return render_template("admin/admindashboard.html") 

@app.route('/admin/add_doctors',methods=["GET","POST"]) #in admin this function is used to add doctors
def add_doctors():
    if request.method=='POST':
        id=request.form['id']
        name=request.form['name']
        speciality=request.form['speciality']
        experience=request.form['experience']
        
        conn=get_db_connection()
        cur=conn.cursor()
        cur.execute("INSERT INTO doctor(id,name,speciality,experience) VALUES (%s,%s,%s,%s)",(id,name,speciality,experience))
        conn.commit()
        cur.close()
        conn.close()
        
    return render_template("admin/adddoctors.html")

@app.route('/admin/add_disease',methods=["GET","POST"]) #in admin section this page is use to add disease
def add_disease():
    if request.method=="POST":
        id=request.form['Id']
        name=request.form['name']
        symtoms=request.form['symtoms']
        specialist=request.form['specialist']
        
        conn=get_db_connection()
        cur=conn.cursor()
        cur.execute("INSERT INTO disease(id,name,symtom,specialist) VALUES (%s,%s,%s,%s)",(id,name,symtoms,specialist))
        conn.commit()
        cur.close()
        conn.close()
        
        
    return render_template("admin/adddisease.html")

@app.route("/register",methods=["GET","POST"]) # user register page
def register():
    if request.method =="POST":
        uname=request.form['name']
        uphono=request.form['phno']
        umail=request.form['email']
        upwd=request.form['password']
        
        conn=get_db_connection()
        cur=conn.cursor()
        cur.execute("INSERT INTO USER(name,email,password,phone) VALUES (%s,%s,%s,%s)",(uname,umail,upwd,uphono))
        conn.commit()
        cur.close()
        conn.close()
        
        return redirect("/login")
    return render_template("user/register.html")




@app.route("/login", methods=["POST","GET"]) #user login page
def login():
    if request.method == "POST":
        
        uphone=request.form["phone"] 
        upwd=request.form["password"]
        
        conn=get_db_connection()
        cur=conn.cursor()
        cur.execute("SELECT name,phone,password FROM user WHERE phone=%s AND password=%s",(uphone,upwd))
        user=cur.fetchone()
        cur.close()
        conn.close()
        
        if user:
            session["phone"]= uphone
            session["name"]=user[0]
            return redirect("/haha")
        else:
            return render_template("user/login.html", msg="Invalid credentials ")
        
    return render_template("user/login.html")

@app.route("/success")
def success():
    return render_template("user/success.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

@app.route("/haha")
def haha():
    conn=get_db_connection()
    cur=conn.cursor()
    cur.execute("SELECT * FROM disease")
    data=cur.fetchall()
    cur.close()
    conn.close()
    return render_template("user/haha.html",disease=data)

from datetime import date

from mysql.connector import IntegrityError
from datetime import date

@app.route("/doctor/<string:id>", methods=["GET", "POST"])
def book_doctor(id):

    if "phone" not in session:
        return redirect("/login")

    uphone = session["phone"]

    AVAILABLE_TIMES = [
        "10:00 AM", "11:00 AM", "12:00 PM", "02:00 PM", "03:00 PM"
    ]

    today = date.today().strftime("%Y-%m-%d")

    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == "POST":
        selected_date = request.form["date"]
        selected_time = request.form["time"]

        try:
            cur.execute(
                """INSERT INTO appointment
                   (doctor_id, user_phone, appointment_date, appointment_time)
                   VALUES (%s,%s,%s,%s)""",
                (id, uphone, selected_date, selected_time)
            )
            conn.commit()

            return redirect("/success")

        except IntegrityError:
            conn.rollback()
            error = "❌ This slot is already booked. Please choose another."

        finally:
            cur.close()
            conn.close()

        return render_template(
            "user/book.html",
            error=error,
            available_times=AVAILABLE_TIMES,
            today=today
        )

    # GET request
    cur.execute(
        "SELECT appointment_time FROM appointment WHERE doctor_id=%s AND appointment_date=%s",
        (id, today)
    )
    booked = [row[0] for row in cur.fetchall()]
    available_times = [t for t in AVAILABLE_TIMES if t not in booked]

    cur.close()
    conn.close()

    return render_template(
        "user/book.html",
        available_times=available_times,
        today=today
    )


if __name__ == "__main__":
    app.run(debug=True)
