document.addEventListener("DOMContentLoaded", function () {

  let index = 0;
  let imgs = document.querySelectorAll(".slider img");
  let dotsBox = document.getElementById("dots");
  let captionBox = document.getElementById("caption");

  captionBox.innerText = imgs[0].dataset.text;

  if (!dotsBox || imgs.length === 0) {
    console.error("Slider images or dots container not found");
    return;
  }

  // CREATE DOTS AUTOMATICALLY
  imgs.forEach((img, i) => {
    let dot = document.createElement("span");
    dot.className = "dot";
    if (i === 0) dot.classList.add("active");

    dot.addEventListener("click", function() {
        window.go(i);
    });

    dotsBox.appendChild(dot);
  });

  let dots = document.querySelectorAll(".dot");

  function show(i) {
    if (!imgs[i] || !dots[i]) return;

    imgs.forEach(img => img.classList.remove("active"));
    dots.forEach(dot => dot.classList.remove("active"));

    imgs[i].classList.add("active");
    dots[i].classList.add("active");

    captionBox.innerText = imgs[i].dataset.text;
  }

  window.change = function (n) {
    index += n;

    if (index >= imgs.length) index = 0;
    if (index < 0) index = imgs.length - 1;

    show(index);
  }

  window.go = function (n) {
    index = n;
    show(index);
  }

  // AUTO SLIDE
  setInterval(() => {
    change(1);
  }, 3000);

});
