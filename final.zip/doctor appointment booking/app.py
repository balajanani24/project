from flask import Flask, render_template, request, redirect, session, url_for
import mysql.connector
from numpy import convolve
app = Flask(__name__)

app = Flask(__name__)
app.secret_key = "supersecretkey123" 

def get_db_connection(): #db connection
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Balajanani2406",
        database="healthcare"
    )


@app.route("/") #default home page
def home():
    return render_template("user/login.html")

@app.route('/admin',methods=["GET","POST"]) # Admin login with authentication
def admin_login():
    if request.method=="POST":
        username =request.form["username"]
        password=request.form["password"]
        
        if username == "Janani" and password == "2406":
            session["Janani"]= True
            return redirect(url_for("admindashboard"))
        else:
            return "Invalid Credentials"
        
    return render_template("admin/adminlogin.html")
    
@app.route('/admin/show_doctors') #in admin this is show doctor page
def show_doctor():
    conn=get_db_connection()
    cur=conn.cursor()
    cur.execute("SELECT * FROM doctor")    
    data=cur.fetchall()
    cur.close()
    conn.close()
    return render_template("admin/showdoctor.html",doctors=data)

@app.route('/admin/show_disease') #in admin side this is show disease page
def show_disease():
    conn=get_db_connection()
    cur=conn.cursor()
    cur.execute("SELECT * from disease")
    data=cur.fetchall()
    cur.close()
    conn.close()
    return render_template("admin/showdisease.html" ,disease=data)

@app.route("/deletedoc/<string:Id>")
def delete_doctor(Id):
    conn=get_db_connection()
    cur=conn.cursor()
    cur.execute("DELETE FROM doctor where id=%s",(Id,))
    conn.commit()
    cur.close()
    conn.close()
    return redirect("/admin/show_doctors")

@app.route("/disease", methods=["GET", "POST"])
def disease():
    conn = get_db_connection()
    cur = conn.cursor()

    # Get all dropdown options
    cur.execute("SELECT DISTINCT speciality FROM doctor")
    specialities = [row[0] for row in cur.fetchall()]

    # Selected speciality
    selected = request.form.get("speciality") if request.method == "POST" else ""

    # Fetch doctors based on selection
    if selected:
        cur.execute("SELECT id,name,speciality,experience FROM doctor WHERE speciality=%s", (selected,))
    else:
        cur.execute("SELECT id,name,speciality,experience FROM doctor")

    doctors = cur.fetchall()

    cur.close()
    conn.close()

    return render_template("user/disease.html",specialities=specialities,doctors=doctors,selected=selected)





@app.route("/deletedis/<string:Id>")
def delete_disease(Id):
    conn=get_db_connection()
    cur=conn.cursor()
    cur.execute("DELETE FROM disease where id=%s",(Id,))
    conn.commit()
    cur.close()
    conn.close()
    return redirect("/admin/show_disease")


  

@app.route('/admindashboard') #admin dashboard
def admindashboard():
    return render_template("admin/admindashboard.html") 

from werkzeug.security import generate_password_hash

@app.route("/admin/add_doctor", methods=["GET", "POST"])
def add_doctors():
    if request.method == "POST":
        name = request.form["name"]
        speciality = request.form["speciality"]
        experience = request.form["experience"]
        password = request.form["password"]


        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute(
            "INSERT INTO doctor (name, speciality, experience, password) VALUES (%s,%s,%s,%s)",
            (name, speciality, experience, password)
        )

        conn.commit()
        cur.close()
        conn.close()

        return "Doctor added successfully"

    return render_template("admin/adddoctors.html")


@app.route('/admin/add_disease',methods=["GET","POST"]) #in admin section this page is use to add disease
def add_disease():
    if request.method=="POST":
        id=request.form['Id']
        name=request.form['name']
        symtoms=request.form['symtoms']
        specialist=request.form['specialist']
        
        conn=get_db_connection()
        cur=conn.cursor()
        cur.execute("INSERT INTO disease(id,name,symtom,specialist) VALUES (%s,%s,%s,%s)",(id,name,symtoms,specialist))
        conn.commit()
        cur.close()
        conn.close()
        
        
    return render_template("admin/adddisease.html")

from werkzeug.security import check_password_hash

@app.route('/doclogin', methods=['GET', 'POST'])
def doctorlogin():
    
    if request.method == "POST":
        docid = request.form['Id']
        docpwd = request.form['password']

        conn = get_db_connection()
        cur = conn.cursor()

        # ✅ Fetch hash only by doctor id
        cur.execute(
            "SELECT id, password FROM doctor WHERE id=%s",
            (docid,)
        )
        doctor = cur.fetchone()

        cur.close()
        conn.close()

        if doctor and doctor[1] == docpwd:
            session['doctor_id'] = doctor[0]
            return redirect('/docdashboard')
        else:
            return render_template("doctor/login.html", msg="Invalid credentials")



    return render_template('doctor/login.html')

@app.route('/doctor/appointment')
def view_appointment():
    if "doctor_id" not in session:
        return redirect("/doclogin")

    doctor_id = session["doctor_id"]

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT id, user_phone, appointment_date, appointment_time, queue_number, status
        FROM appointment
        WHERE doctor_id=%s
    """, (doctor_id,))

    appointments = cur.fetchall()

    cur.close()
    conn.close()

    return render_template(
        "doctor/viewappointments.html",
        appointments=appointments
    )


@app.route('/docdashboard')   
def docdashboard():
    return render_template('/doctor/dashboard.html')      

@app.route("/register",methods=["GET","POST"]) # user register page
def register():
    if request.method =="POST":
        uname=request.form['name']
        uphono=request.form['phno']
        umail=request.form['email']
        upwd=request.form['password']
        
        conn=get_db_connection()
        cur=conn.cursor()
        cur.execute("INSERT INTO USER(name,email,password,phone) VALUES (%s,%s,%s,%s)",(uname,umail,upwd,uphono))
        conn.commit()
        cur.close()
        conn.close()
        
        return redirect("/login")
    return render_template("user/register.html")




@app.route("/login", methods=["POST","GET"]) #user login page
def login():
    if request.method == "POST":
        
        uphone=request.form["phone"] 
        upwd=request.form["password"]
        
        conn=get_db_connection()
        cur=conn.cursor()
        cur.execute("SELECT name,phone,password FROM user WHERE phone=%s AND password=%s",(uphone,upwd))
        user=cur.fetchone()
        cur.close()
        conn.close()
        
        if user:
            session["phone"]= uphone
            session["name"]=user[0]
            return redirect("/haha")
        else:
            return render_template("user/login.html", msg="Invalid credentials ")
        
    return render_template("user/login.html")

@app.route("/success")
def success():
    return render_template("user/success.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

@app.route("/haha")
def haha():
    conn=get_db_connection()
    cur=conn.cursor()
    cur.execute("SELECT * FROM disease")
    data=cur.fetchall()
    cur.close()
    conn.close()
    return render_template("user/haha.html",disease=data)

from datetime import date

from mysql.connector import IntegrityError
from datetime import date

@app.route("/doctor/<string:id>", methods=["GET", "POST"])
def book_doctor(id):

    if "phone" not in session:
        return redirect("/login")

    uphone = session["phone"]

    AVAILABLE_TIMES = [
        "10:00 AM", "11:00 AM", "12:00 PM", "02:00 PM", "03:00 PM"
    ]

    today = date.today().strftime("%Y-%m-%d")

    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == "POST":
        selected_date = request.form["date"]
        selected_time = request.form["time"]

        try:
            cur.execute(
                """INSERT INTO appointment
                   (doctor_id, user_phone, appointment_date, appointment_time)
                   VALUES (%s,%s,%s,%s)""",
                (id, uphone, selected_date, selected_time)
            )
            conn.commit()

            return redirect("/success")

        except IntegrityError:
            conn.rollback()
            error = "❌ This slot is already booked. Please choose another."

        finally:
            cur.close()
            conn.close()

        return render_template(
            "user/book.html",
            error=error,
            available_times=AVAILABLE_TIMES,
            today=today
        )

    # GET request
    cur.execute(
        "SELECT appointment_time FROM appointment WHERE doctor_id=%s AND appointment_date=%s",
        (id, today)
    )
    booked = [row[0] for row in cur.fetchall()]
    available_times = [t for t in AVAILABLE_TIMES if t not in booked]

    cur.close()
    conn.close()

    return render_template(
        "user/book.html",
        available_times=available_times,
        today=today
    )
@app.route("/patient/track")
def patient_track():
    if "phone" not in session:
        return redirect("/login")

    phone = session["phone"]

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute("""
        SELECT id, status, queue_number
        FROM appointment
        WHERE user_phone=%s
        ORDER BY id DESC
        LIMIT 1
    """, (phone,))

    appointment = cur.fetchone()

    cur.close()
    conn.close()

    return render_template(
        "user/track.html",
        appointment=appointment
    )

@app.route("/doctor/update_status/<int:appointment_id>/<string:status>")
def update_status(appointment_id, status):
    if "doctor_id" not in session:
        return redirect("/doclogin")

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute(
        "UPDATE appointment SET status=%s WHERE id=%s",
        (status, appointment_id)
    )
    conn.commit()

    cur.close()
    conn.close()

    return redirect("/doctor/appointment")

from datetime import date

@app.route("/admin/op_patient", methods=["GET", "POST"])
def op_patient():
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == "POST":
        phone = request.form["phone"]
        doctor_id = request.form["doctor_id"]

        today = date.today()

        cur.execute("""
            INSERT INTO appointment
            (doctor_id, user_phone, appointment_date, appointment_time, status)
            VALUES (%s, %s, %s, %s, %s)
        """, (doctor_id, phone, today, "OP", "OP"))

        conn.commit()
        cur.close()
        conn.close()

        return redirect("/admin")

    # GET → show doctors
    cur.execute("SELECT id, name, speciality FROM doctor")
    doctors = cur.fetchall()

    cur.close()
    conn.close()

    return render_template(
        "admin/op_patient.html",
        doctors=doctors
    )





from datetime import date

@app.route("/op_visit", methods=["GET", "POST"])
def op_visit():
    if "phone" not in session:
        return redirect("/login")

    phone = session["phone"]
    today = date.today()

    conn = get_db_connection()
    cur = conn.cursor()

    # ---------- GET : show free General Physicians ----------
    if request.method == "GET":
        cur.execute("""
            SELECT d.id, d.name
            FROM doctor d
            WHERE d.speciality LIKE %s
            AND d.id NOT IN (
                SELECT doctor_id
                FROM appointment
                WHERE appointment_date = %s
            )
        """, ("%General%", today))

        doctors = cur.fetchall()

        cur.close()
        conn.close()
        return render_template("user/op_visit.html", doctors=doctors)

    # ---------- POST : user selects doctor ----------
    doctor_id = request.form["doctor_id"]

    # THIS IS WHERE YOU ADD QUEUE NUMBER LOGIC
    cur.execute("""
        SELECT COUNT(*) 
        FROM appointment
        WHERE doctor_id=%s AND appointment_date=%s
    """, (doctor_id, today))

    queue_number = cur.fetchone()[0] + 1
    #  END OF QUEUE LOGIC

    # ---------- INSERT OP APPOINTMENT ----------
    cur.execute("""
        INSERT INTO appointment
        (doctor_id, user_phone, appointment_date, appointment_time, status, queue_number)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (doctor_id, phone, today, "OP", "Booked", queue_number))

    conn.commit()
    cur.close()
    conn.close()

    return redirect("/patient/track")




if __name__ == "__main__":
    app.run(debug=True)
