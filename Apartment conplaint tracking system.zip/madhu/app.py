from flask import Flask, render_template, request, redirect, session
import mysql.connector

app = Flask(__name__)
app.secret_key = "secret123"

# ---------- DATABASE ----------
def get_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Balajanani2406",
        database="apartment"
    )

# ================= ADMIN (STATIC LOGIN) =================

@app.route("/adminlogin", methods=["GET", "POST"])
def adminlogin():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        # STATIC ADMIN CREDENTIALS
        if username == "Janani" and password == "2406":
            session["admin"] = "Janani"
            return redirect("/admindashboard")

    return render_template("admin/adminlogin.html")


@app.route("/admindashboard")
def admindashboard():
    if "admin" not in session:
        return redirect("/adminlogin")
    return render_template("admin/admindashboard.html")


@app.route("/admin/complaints")
def admin_complaints():
    if "admin" not in session:
        return redirect("/adminlogin")

    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT * FROM complaints")
    data = cur.fetchall()
    db.close()

    return render_template("admin/viewcomplaints.html", data=data)

@app.route("/admin/addstaff", methods=["GET","POST"])
def add_staff():
    if "admin" not in session:
        return redirect("/adminlogin")

    if request.method == "POST":
        db = get_db()
        cur = db.cursor()
        cur.execute(
            "INSERT INTO staff (username, password, work_type) VALUES (%s,%s,%s)",
            (
                request.form["username"],
                request.form["password"],
                request.form["work_type"]
            )
        )
        db.commit()
        db.close()
        return redirect("/admindashboard")

    return render_template("admin/addstaff.html")


@app.route("/admin/update/<int:cid>", methods=["GET", "POST"])
def admin_update(cid):
    if "admin" not in session:
        return redirect("/adminlogin")

    db = get_db()
    cur = db.cursor()

    # 🔹 If form submitted → update status
    if request.method == "POST":
        cur.execute(
            "UPDATE complaints SET status=%s WHERE id=%s",
            (request.form["status"], cid)
        )
        db.commit()
        db.close()
        return redirect("/admin/complaints")

    # 🔹 GET current status
    cur.execute("SELECT status FROM complaints WHERE id=%s", (cid,))
    current_status = cur.fetchone()

    # ✅ ADD THIS BLOCK HERE (IMPORTANT)
    if current_status and current_status[0] == "Resolved":
        db.close()
        return redirect("/admin/completed")

    db.close()

    return render_template(
        "admin/updatesstatus.html",
        cid=cid,
        current_status=current_status[0] if current_status else ""
    )

@app.route("/admin/completed")
def admin_completed():
    if "admin" not in session:
        return redirect("/adminlogin")

    db = get_db()
    cur = db.cursor()
    cur.execute(
        "SELECT * FROM complaints WHERE status = 'Resolved'"
    )
    data = cur.fetchall()
    db.close()

    return render_template("admin/completed.html", data=data)




# ================= USER =================

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        db = get_db()
        cur = db.cursor()
        cur.execute(
            """
            INSERT INTO users (username, password, plot_no, block, phone)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (
                request.form["username"],
                request.form["password"],
                request.form["plot_no"],
                request.form["block"],
                request.form["phone"]
            )
        )
        db.commit()
        db.close()
        return redirect("/")

    return render_template("user/register.html")


@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        db = get_db()
        cur = db.cursor()
        cur.execute(
            "SELECT id FROM users WHERE username=%s AND password=%s",
            (request.form["username"], request.form["password"])
        )
        user = cur.fetchone()
        db.close()

        if user:
            session["uid"] = user[0]
            return redirect("/dashboard")

    return render_template("user/login.html")


@app.route("/dashboard")
def dashboard():
    if "uid" not in session:
        return redirect("/login")
    return render_template("user/dashboard.html")

@app.route("/addcomplaint", methods=["GET", "POST"])
def addcomplaint():
    if "uid" not in session:
        return redirect("/login")

    if request.method == "POST":
        db = get_db()
        cur = db.cursor()

        #  Get user's phone number from users table
        cur.execute(
            "SELECT phone FROM users WHERE id=%s",
            (session["uid"],)
        )
        phone = cur.fetchone()[0]

        #  Insert complaint with phone number
        cur.execute(
            """
            INSERT INTO complaints
            (user_id, flat_no, block, category, description, status, phone)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (
                session["uid"],
                request.form["flat_no"],
                request.form["block"],
                request.form["category"],
                request.form["description"],
                "Pending",
                phone
            )
        )

        db.commit()
        db.close()

        return render_template("user/success.html")

    return render_template("user/addcomplaint.html")




@app.route("/track")
def track():
    if "uid" not in session:
        return redirect("/login")

    db = get_db()
    cur = db.cursor()
    cur.execute(
        "SELECT flat_no, block, category, status FROM complaints WHERE user_id=%s",
        (session["uid"],)
    )

    data = cur.fetchall()
    db.close()

    return render_template("user/trackcomplaint.html", data=data)

# ================= STAFF =================

@app.route("/staff/dashboard")
def staff_dashboard():
    if "staff_id" not in session:
        return redirect("/staff/login")

    db = get_db()
    cur = db.cursor()
    cur.execute(
        """
        SELECT flat_no, block, category, description, phone, status
        FROM complaints
        WHERE category = %s
        """,
        (session["work_type"],)
    )
    complaints = cur.fetchall()
    db.close()

    return render_template(
        "staff/dashboard.html",
        complaints=complaints,
        work_type=session["work_type"]
    )



@app.route("/staff/complaints")
def staff_complaints():
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT * FROM complaints")
    data = cur.fetchall()
    db.close()
    return render_template("staff/assignedcomplaints.html", complaints=data)


@app.route("/staff/update/<int:cid>", methods=["GET", "POST"])
def staff_update(cid):
    if request.method == "POST":
        db = get_db()
        cur = db.cursor()
        cur.execute(
            "UPDATE complaints SET status=%s WHERE id=%s",
            (request.form["status"], cid)
        )
        db.commit()
        db.close()
        return redirect("/staff/complaints")

    return render_template("staff/updatestatus.html", cid=cid)
@app.route("/staff/login", methods=["GET","POST"])
def staff_login():
    if request.method == "POST":
        db = get_db()
        cur = db.cursor()
        cur.execute(
            "SELECT id, work_type FROM staff WHERE username=%s AND password=%s",
            (request.form["username"], request.form["password"])
        )
        staff = cur.fetchone()
        db.close()

        if staff:
            session["staff_id"] = staff[0]
            session["work_type"] = staff[1]
            return redirect("/staff/dashboard")

    return render_template("staff/login.html")

# ================= LOGOUT =================

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)
